package WorkingwithAbstractionExercise.Problem1CardSuit;

public enum Cards {

    CLUBS, DIAMONDS, HEARTS, SPADES;

}
